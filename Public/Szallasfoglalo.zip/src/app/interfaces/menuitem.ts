export interface MenuItem{
  label: string;
  url: string;
  // opcionális attribútumok:
  icon?: string;
 // command?(event:Event):void;
}
